package com.example.myapplication

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class AnyName : ViewModel(){
    val saveResult: MutableLiveData<String> = MutableLiveData("");
}