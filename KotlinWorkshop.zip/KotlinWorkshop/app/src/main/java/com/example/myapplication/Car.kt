package com.example.myapplication

data class Car(val name: String, val speed: Int?)
