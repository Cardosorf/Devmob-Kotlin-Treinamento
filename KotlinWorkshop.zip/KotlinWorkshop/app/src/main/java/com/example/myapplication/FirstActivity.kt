package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import kotlinx.android.synthetic.main.activity_main.*

class FirstActivity : AppCompatActivity() {

    //val model: AnyName by viewModels()



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val model = ViewModelProviders.of(this).get(AnyName::class.java)

        val dataObs = Observer<String>{ novoChar ->
            result.text = novoChar
        }

        model.saveResult.observe(this, dataObs)

        //result.text = model.saveResult.value

        compareButton.setOnClickListener {

            if(firstCarName.text.toString() == secondCarName.text.toString()){

                result.text =  "Mesmo nome de carro, por favor altere.kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk"

                model.saveResult.value = result.text.toString()

            }
            else {
                val car1 = Car(
                    firstCarName.text.toString(),
                    firstCarVelocity.text.toString().toIntOrNull()
                )

                //val car1 = Car(firstCarName.text.toString(), firstCarVelocity.text.toString().toInt())

                val car2 = Car(
                    secondCarName.text.toString(),
                    secondCarVelocity.text.toString().toIntOrNull()
                )

                //val car2 = Car(secondCarName.text.toString(), secondCarVelocity.text.toString().toInt())

                //result.text = if(car1.speed > car2.speed) car1.name else car2.name

                result.text = test2(car1, car2)

                model.saveResult.value  = result.text.toString()
            }
        }
    }

    //fun test(param1 : Car, param2 : Car) = if(param1.speed ?:0 > param2.speed ?:0) param1.name else param2.name

    fun test2(param1 : Car, param2 : Car): String {

       return when(param1.speed ?:0 > param2.speed ?:0){
            true -> param1.name
            false -> param2.name
        }

        /*
        return if(param1.speed > param2.speed)
            param1.name
        else
            param2.name
        */

    }



}