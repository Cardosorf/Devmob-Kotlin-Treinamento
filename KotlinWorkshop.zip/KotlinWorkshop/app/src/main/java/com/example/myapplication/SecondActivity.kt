package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class SecondActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        compareButton.setOnClickListener {
            val car1 = Car(firstCarName.text.toString(), firstCarVelocity.text.toString().toIntOrNull())

            val car2 = Car(secondCarName.text.toString(), secondCarVelocity.text.toString().toIntOrNull())

            result.text = faster(car1, car2).speed.toString()
        }
    }

    fun faster(first : Car, second: Car): Car = if (first.speed ?:0 > second.speed ?:0) first else second
}
